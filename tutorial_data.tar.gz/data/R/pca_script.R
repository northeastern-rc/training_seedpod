cov<-as.matrix(read.table("../pcangsd/pca_out.cov"))
e<-eigen(cov)
plot(e$vectors[,1:2])
e$values/sum(e$values)
